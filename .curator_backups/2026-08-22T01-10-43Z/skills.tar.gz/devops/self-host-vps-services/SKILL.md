---
name: self-host-vps-services
description: Deploy node services on saturia VPS behind CF Tunnel.
---

# Self-Hosting Node Services on the saturia VPS

Use this when the user asks to install/run any web service (n8n, 9Router, a bot dashboard, etc.) on
their VPS and expose it on a `*.saturia.codes` (or `*.satzz.online`) subdomain via the existing
Cloudflare Tunnel. No Docker is available on this box — everything is bare node + systemd.

## Environment facts (persistent for this VPS)
- **Node is NOT in default PATH.** It lives only at `/home/saturia/.hermes/node/bin/node`
  (npm/npx beside it). `9router` fails with `/usr/bin/env: 'node': No such file or directory`, and
  any systemd `ExecStart=/path/cli.js` exits 127.
- **Fix (do this first, once):** symlink into `/usr/local/bin` so systemd, CLI tools, and shells
  all find node:
  ```bash
  sudo ln -sf /home/saturia/.hermes/node/bin/node /usr/local/bin/node
  sudo ln -sf /home/saturia/.hermes/node/bin/npm  /usr/local/bin/npm
  sudo ln -sf /home/saturia/.hermes/node/bin/npx  /usr/local/bin/npx
  ```
- Cloudflare Tunnel runs as `cloudflared.service` (root), config `/etc/cloudflared/config.yml`,
  `ingress:` maps hostnames → `http://localhost:PORT`. `api.saturia.codes` (4000) and
  `agent.satzz.online` (9119) already exist — append, don't overwrite.
- **No CF API token / origin cert on the box.** Create DNS CNAMEs via CF REST API with a token the
  user supplies (Zone DNS:Edit for `saturia.codes`). See `references/cloudflare-dns-api.md`.

## Standard deploy sequence
1. `npm install` the app in `/home/saturia/<app>` (or `npm install -g` for CLI tools).
2. Handle native builds (per-app notes below).
3. systemd unit `/etc/systemd/system/<app>.service`:
   - `User=saturia`, `WorkingDirectory=/home/saturia/<app>`
   - `Environment=PATH=/home/saturia/.hermes/node/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin`
   - `ExecStart=/home/saturia/.hermes/node/bin/node <absolute/entry.js>` — use the **absolute node
     binary**, never a bare `cli.js` shebang (fails under systemd without PATH).
   - `Restart=on-failure`, `RestartSec=5`.
4. `sudo systemctl daemon-reload && sudo systemctl enable --now <app>.service`.
5. Append ingress to `/etc/cloudflared/config.yml`, `sudo systemctl restart cloudflared`.
6. Create CF DNS CNAME. Verify: `curl -I https://<sub>.saturia.codes` → 200.

## Per-app quirks
### n8n (port 5678)
- `npm install n8n` then `npm install sqlite3 --save`. npm **blocks install-scripts**, so the
  native `.node` is missing → n8n crashes "SQLite package has not been found installed". Fix:
  ```bash
  npm install-scripts approve sqlite3 && npm rebuild sqlite3
  ```
  Verify `node_modules/sqlite3/build/Release/node_sqlite3.node` exists, then restart.
- Web UI `/` → owner setup. Set `N8N_PORT`, `N8N_HOST`, `N8N_PROTOCOL=https`, `WEBHOOK_URL` in `.env`.

### 9Router (port 20128, OpenAI-compatible at `/v1`)
- `npm install -g 9router` → bin `/home/saturia/.local/bin/9router`.
- **DO NOT run `cli.js` under systemd** — it's an interactive launcher that spawns the server then
  exits 0, so systemd kills the child. Spawn the bundled Next.js server directly:
  ```
  ExecStart=/home/saturia/.hermes/node/bin/node /home/saturia/.local/lib/node_modules/9router/app/custom-server.js
  Environment=PORT=20128
  Environment=HOSTNAME=0.0.0.0
  ```
- **Web password**: default is `123456` when `settings.password` is null. Reset (`9router
  --reset-password`, needs node in PATH) only clears the hash to null. Set a custom password by
  writing a bcrypt hash into the `settings` table, or just log in with `123456` and change in UI.
  See `references/9router-internals.md`.
- **9Router ALWAYS streams SSE** and has no stream toggle. This breaks n8n's AI Assistant
  "Connect a model" verification (it expects JSON). To route n8n's Assistant through the
  9Router gateway, deploy the non-streaming proxy in `references/n8n-9router-gateway.md`
  (listens on **5680**; n8n credential Base URL → `http://127.0.0.1:5680/v1`).

## Pitfalls
- **Port 5679 is already taken by n8n itself.** Any companion proxy/listener for n8n must use
  a different port (the 9Router-to-n8n proxy in `references/n8n-9router-gateway.md` uses 5680).
  A silent `EADDRINUSE` on 5679 makes the proxy crash-loop with a misleading HTML "Cannot POST"
  error from n8n.
- **When an app returns SSE but the caller expects JSON** (e.g. n8n AI Assistant verifying a model
  against 9Router), don't keep poking the UI — read the app's `verify`/`test` source to learn what
  response shape it parses, then insert a thin proxy that forces `stream:false` / converts SSE→JSON.
  Confirmed recipe in `references/n8n-9router-gateway.md`.
- **Don't reverse-engineer an app's password storage from its minified build.** Check for a default
  password / official CLI reset / `INITIAL_PASSWORD` env FIRST. For 9Router it was the documented
  default `123456` + CLI reset — grep through `middleware.js` was wasted effort.
- **`npm install-scripts` blocks native postinstalls** here by default. If a package needs a native
  module and crashes at runtime, approve + rebuild, not reinstall.
- **Tunnel needs a restart** after editing `config.yml` for new ingress to take effect.
- **DNS must exist before the domain resolves** — tunnel 502s until the CNAME is created.
